package actores;

import dominio.Sucursal;

public class Recepcionista extends Personal {

	public Recepcionista(Integer idPersonal, String nombre, String apellidoPat, 
	String apellidoMat, Sucursal suc ) {
		super(idPersonal, nombre, apellidoPat, apellidoMat, suc);
	}

	
}