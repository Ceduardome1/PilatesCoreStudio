package bd;

import dominio.Reservacion;

public class RepositorioReservaciones {
	
	public void insertar( Reservacion reservacion, BD bd ) throws Exception {
		
	}
	
}