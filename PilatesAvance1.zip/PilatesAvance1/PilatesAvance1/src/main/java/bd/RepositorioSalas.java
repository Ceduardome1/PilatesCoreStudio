package bd;

import dominio.Sala;

public class RepositorioSalas {

	public Sala buscar( Integer idSala, BD bd ) throws Exception {
		
		return null;
	}
	
	public void actualizar( Sala sala, BD bd ) throws Exception {
		
	}
	
}
