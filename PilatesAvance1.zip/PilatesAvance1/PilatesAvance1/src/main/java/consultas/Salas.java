package consultas;

public class Salas {
	
	public static void main( String args[] ) {

	}
	
}
