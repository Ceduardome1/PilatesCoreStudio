package controladoresDominio;

public class ControladorClase {

}
