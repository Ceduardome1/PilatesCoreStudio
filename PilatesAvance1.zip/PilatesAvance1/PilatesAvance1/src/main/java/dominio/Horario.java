package dominio;

import java.time.LocalDate;
import java.time.LocalTime;

public class Horario {

private String fecha;
private String hora;
	
	public Horario(String fecha, String hora) {
		this.fecha = fecha;
		this.hora = hora;
	}

	
	public String getFecha() {
		return fecha;
	}

	public String getHora() {
		return hora;
	}

	public String mostrarFecha() {
		return fecha.toString();
	}
	
	public String mostrarHora() {
		return hora.toString();
	}
}
