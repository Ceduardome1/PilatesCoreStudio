package dominio;

public class Sucursal {

	private final Integer idSucursal;
	private final Direccion direccion;
	
	public Sucursal(int idSucursal, Direccion direccion) {
		this.idSucursal = idSucursal;
		this.direccion = direccion;
	}

	public int getIdSucursal() {
		return idSucursal;
	}

	public Direccion getDireccion() {
		return direccion;
	}

    public boolean equalsIgnoreCase(Sucursal sucursal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
	
}