package inserciones;

public class Salas {

	public static void main( String args[] ) {

	}
	
}
