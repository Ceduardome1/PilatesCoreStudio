package inserciones;

import actores.Administrador;
import actores.Instructor;
import dominio.Clase;
import dominio.Horario;
import dominio.Sala;
import dominio.Direccion;
import dominio.Sucursal;
import bd.BD;

import java.time.LocalTime;

public class insercionesClases {

    public static void main(String[] args) {

        BD bd = new BD();

        try {

            // Sucursal y sala
            Sucursal suc = new Sucursal(
                    1,
                    new Direccion(6700, (short) 25, "Roma Norte", "Puebla")
            );

            Sala sala1 = new Sala(1, suc, 10);
            Sala sala2 = new Sala(2, suc, 12);

            // Instructor ficticio
            Instructor ins = new Instructor(
                    1, "Ana", "Morales", "Cruz", suc
            );

            // Admin ficticio
            Administrador admin = new Administrador(
                    100, "Admin", "General", "Sistema", suc
            );

            // Aquí convertimos a String
            String fecha1 = java.time.LocalDate.now().plusDays(1).toString();
            String fecha2 = java.time.LocalDate.now().plusDays(1).toString();

            Horario h1 = new Horario(fecha1, LocalTime.of(9, 0).toString());
            Horario h2 = new Horario(fecha2, LocalTime.of(10, 0).toString());

            Clase clase1 = new Clase(1, sala1, ins, h1, admin);
            Clase clase2 = new Clase(2, sala2, ins, h2, admin);

            bd.getConexion().store(clase1);
            bd.getConexion().store(clase2);
            bd.confirmarTransaccion();

            System.out.println("CLASES INSERTADAS");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            bd.cerrarConexion();
        }
    }
}
