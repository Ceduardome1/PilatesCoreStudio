package interfaces;

import dominio.Clase;

public interface SelectorClase {
	public abstract void onClaseSeleccionada( Clase clase );
}
