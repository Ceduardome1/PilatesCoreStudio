package interfaces;
import actores.Cliente;

public interface SelectorCliente {
	void onClienteSeleccionado( Cliente cliente);
}