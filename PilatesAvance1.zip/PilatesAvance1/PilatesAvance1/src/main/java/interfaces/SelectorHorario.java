package interfaces;
import dominio.Horario;

public interface SelectorHorario {
	public abstract void onHorarioSeleccionado( Horario horario );
}
