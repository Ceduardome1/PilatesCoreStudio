package interfaces;
import actores.Instructor;

public interface SelectorInstructor {
	public void onInstructorSeleccionado(Instructor instructor); 
}
